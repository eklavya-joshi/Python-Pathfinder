import tkinter

root = tkinter.Tk()



def show():
    lab = tkinter.Label(root, text=var.get()).pack()


var = tkinter.IntVar()
var.set(1)
astar_but = tkinter.Checkbutton(root, text="A*", variable=var, onvalue=1, offvalue=2)
astar_but.pack()

tkinter.Button(root, text="show", command=show()).pack()

tkinter.mainloop()
