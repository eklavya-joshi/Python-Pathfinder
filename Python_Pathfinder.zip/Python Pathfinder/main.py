import tkinter
import pygame

ORANGE = (220, 140, 38)
PURPLE = (124, 9, 232)
PINK = (216, 143, 255)
SKY_BLUE = (66, 148, 214)
YELLOW = (210, 210, 0)
MAROON = (158, 51, 51)
GRAY = (120, 120, 120)
BLACK = (0, 0, 0)

START_COL = (164, 201, 119)
END_COL = (214, 109, 167)
PATH_COL = YELLOW
GRID_COL = (114, 99, 117)
PADD_COL = BLACK
OBST_COL = (26, 58, 145)
FIND_COL = (107, 169, 199)

pygame.init()


class grid_box:
    def __init__(self, xpos, ypos, filled, type, prev, scanned, g_dist, h_dist):
        self.xpos = xpos
        self.ypos = ypos
        self.filled = filled
        self.type = type
        self.prev = prev
        self.scanned = scanned
        self.g_dist = g_dist
        self.h_dist = h_dist

    def fill(self, colour):
        pygame.draw.rect(screen, colour,
                         pygame.Rect(self.xpos, GRID_SIZE - BOX_SIZE - self.ypos, BOX_SIZE - 1, BOX_SIZE - 1), False)
        pygame.draw.rect(screen, PADD_COL,
                         pygame.Rect(self.xpos, GRID_SIZE - BOX_SIZE - self.ypos, BOX_SIZE, BOX_SIZE), 1)
        self.filled = True

    def unfill(self):
        pygame.draw.rect(screen, GRID_COL,
                         pygame.Rect(self.xpos, GRID_SIZE - BOX_SIZE - self.ypos, BOX_SIZE, BOX_SIZE), False)
        pygame.draw.rect(screen, PADD_COL,
                         pygame.Rect(self.xpos, GRID_SIZE - BOX_SIZE - self.ypos, BOX_SIZE, BOX_SIZE), 1)
        self.type = "none"
        self.filled = False


def main():
    start_window()
    global screen
    screen = pygame.display.set_mode((GRID_SIZE, GRID_SIZE))
    screen.fill(GRID_COL)
    global boxes
    boxes = [[grid_box(None, None, None, None, None, None, None, None) for j in range(ROWS)] for i in range(ROWS)]
    make_grid()
    global queue
    queue = []

    running = True
    found_path = False
    global START_BOX
    START_BOX = [int(ROWS / 2 - ROWS / 4), int(ROWS / 2)]
    global END_BOX
    END_BOX = [int(ROWS / 2 + ROWS / 4), int(ROWS / 2)]
    fill_box_on_map((START_BOX[0], START_BOX[1]), START_COL)
    fill_box_on_map((END_BOX[0], END_BOX[1]), END_COL)
    boxes[START_BOX[0]][START_BOX[1]].type = "start"
    boxes[END_BOX[0]][END_BOX[1]].type = "end"

    while running:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p and not found_path:
                    scan_area(START_BOX)
                    end_window(path_find(queue, True), int(get_dist_from_target(START_BOX, END_BOX)))
                    found_path = True
            if not keys[pygame.K_LSHIFT] and get_mouse_coords() != START_BOX and get_mouse_coords() != END_BOX:
                if pygame.mouse.get_pressed(3) == (True, False, False):
                    fill_box_on_map(get_mouse_coords(), OBST_COL)
                    boxes[get_mouse_coords()[0]][get_mouse_coords()[1]].type = "obst"
                elif pygame.mouse.get_pressed(3) == (False, False, True):
                    unfill_box_on_map(get_mouse_coords())

            elif keys[pygame.K_LSHIFT] and event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed(3) == (True, False, False):
                    boxes[START_BOX[0]][START_BOX[1]].unfill()
                    START_BOX = get_mouse_coords()
                    fill_box_on_map((START_BOX[0], START_BOX[1]), START_COL)
                    boxes[START_BOX[0]][START_BOX[1]].type = "start"
                elif pygame.mouse.get_pressed(3) == (False, False, True):
                    boxes[END_BOX[0]][END_BOX[1]].unfill()
                    END_BOX = get_mouse_coords()
                    fill_box_on_map((END_BOX[0], END_BOX[1]), END_COL)
                    boxes[END_BOX[0]][END_BOX[1]].type = "end"
                    get_dist_from_target(START_BOX, END_BOX)

        pygame.display.update()


def get_mouse_coords():
    mx, my = pygame.mouse.get_pos()
    mx = int(mx / BOX_SIZE)
    my = int(my / BOX_SIZE)
    return [mx, my]


def make_grid():
    for x in range(0, GRID_SIZE, BOX_SIZE):
        for y in range(0, GRID_SIZE, BOX_SIZE):
            rect = pygame.Rect(x, GRID_SIZE - BOX_SIZE - y, BOX_SIZE, BOX_SIZE)
            pygame.draw.rect(screen, PADD_COL, rect, 1)

            box = grid_box(x, GRID_SIZE - BOX_SIZE - y, False, "empty", None, False, 0, 0)
            boxes[int(x / BOX_SIZE)][int(y / BOX_SIZE)] = box
    pass


def fill_box_on_map(coords, colour):
    boxes[coords[0]][coords[1]].fill(colour)


def unfill_box_on_map(coords):
    boxes[coords[0]][coords[1]].unfill()


def get_dist_from_target(start, end):
    xdist = end[0] - start[0]
    ydist = end[1] - start[1]
    return abs(xdist) + abs(ydist)  # (xdist ** 2 + ydist ** 2) ** (1 / 2)


def check_node(start, x, y):
    if start[0] + x >= ROWS or start[0] + x < 0 or start[1] + y >= ROWS or start[1] + y < 0 \
            or boxes[start[0] + x][start[1] + y] == boxes[start[0]][start[1]].prev \
            or boxes[start[0] + x][start[1] + y].type is "obst":
        return
    if boxes[start[0]][start[1]].type is not "start" and boxes[start[0]][start[1]].type is not "end":
        fill_box_on_map(start, FIND_COL)
    pygame.display.update()
    if boxes[start[0] + x][start[1] + y].prev is None \
            or boxes[boxes[start[0] + x][start[1] + y].prev[0]][boxes[start[0] + x][start[1] + y].prev[1]].g_dist > \
            boxes[start[0]][start[1]].g_dist:
        boxes[start[0] + x][start[1] + y].prev = start
        boxes[start[0] + x][start[1] + y].g_dist = boxes[start[0]][start[1]].g_dist + (x ** 2 + y ** 2) ** (1 / 2)

    boxes[start[0] + x][start[1] + y].h_dist = get_dist_from_target((start[0] + x, start[1] + y), END_BOX)

    return start[0] + x, start[1] + y


def path_find(queue, is_astar):
    if len(queue) == 0:
        pass
    while len(queue) > 0:
        if not boxes[queue[0][0]][queue[0][1]].scanned:
            scan_area(queue[0])
            boxes[queue[0][0]][queue[0][1]].scanned = True
            if boxes[queue[0][0]][queue[0][1]].type == "end":
                return get_dist_from_node(queue[0], True)
        queue.pop(0)
        y = 0
        for x in range(0, len(queue), 1):
            if queue[x - y] is None:
                del queue[x - y]
                y += 1

        if is_astar:
            get_shortest_fdist()


def scan_area(node_pos):
    queue.append(check_node(node_pos, 1, 0))
    queue.append(check_node(node_pos, 0, 1))
    queue.append(check_node(node_pos, 0, -1))
    queue.append(check_node(node_pos, -1, 0))


def get_dist_from_node(node, is_colour):
    curr_node = boxes[node[0]][node[1]].prev
    dist = 1
    while curr_node is not None and boxes[curr_node[0]][curr_node[1]].type is not "start":
        if is_colour:
            pygame.time.wait(int(25000 / GRID_SIZE))
            fill_box_on_map(curr_node, PATH_COL)
        pygame.display.update()
        curr_node = boxes[curr_node[0]][curr_node[1]].prev
        dist += 1
    return dist


def get_shortest_fdist():
    box = boxes[queue[0][0]][queue[0][1]]
    y = 0
    for x in range(1, len(queue), 1):
        box1 = boxes[queue[x][0]][queue[x][1]]
        if box.h_dist + box.g_dist > box1.h_dist + box1.g_dist:
            box = box1
            y = x
        elif box.h_dist + box.g_dist == box1.h_dist + box1.g_dist and box.h_dist > box1.h_dist:
            box = box1
            y = x
    lowest_box = (queue[y][0], queue[y][1])
    del queue[y]
    queue.insert(0, lowest_box)


def start_window():
    root = tkinter.Tk()
    root.wm_title("")
    root.geometry("180x100")
    title_text = tkinter.Label(root, text="Grid dimensions", font="ArialBD")
    title_text.place(height=20, width=150, x=10, y=10)
    text1 = tkinter.Label(root, text="Grid Width: ")
    text1.place(height=20, width=70, y=30)
    grid_input = tkinter.Entry(root)
    grid_input.place(height=20, width=40, x=110, y=30)
    text2 = tkinter.Label(root, text="Number Of Rows: ")
    text2.place(height=20, width=100, y=50)
    row_input = tkinter.Entry(root)
    row_input.place(height=20, width=40, x=110, y=50)
    astar = tkinter.StringVar()
    astar_but = tkinter.Radiobutton(root, text="A*", variable=astar, value="abc")
    astar_but.place(height=20, width=20, x=20, y=30)
    grid_but = tkinter.Button(root, text="OK", command=lambda: pick_grid(grid_input.get(), row_input.get(), astar, root))
    grid_but.place(height=20, width=40, x=110, y=70)
    root.mainloop()


def pick_grid(grid, row, astar, root):
    global is_astar
    print(astar)
    #is_astar = astar.get()
    try:
        int(grid)
        int(row)
    except:
        root.destroy()
        start_window()
        return
    if int(grid) % int(row) != 0:
        root.destroy()
        start_window()
        return
    global GRID_SIZE
    GRID_SIZE = int(grid)
    global ROWS
    ROWS = int(row)
    global BOX_SIZE
    BOX_SIZE = int(GRID_SIZE / ROWS)
    root.destroy()


def end_window(path_dist, true_dist):
    pygame.display.update()
    root = tkinter.Tk()
    root.wm_title("")
    root.geometry("180x100")
    title_text = tkinter.Label(root, text="Results", font="ArialBD")
    title_text.place(height=20, width=80, x=10, y=10)
    text1 = tkinter.Label(root, text="Path Distance: " + str(path_dist), relief=tkinter.GROOVE)
    text1.place(height=20, width=130, x=10, y=30)
    text2 = tkinter.Label(root, text="True Distance: " + str(true_dist), relief=tkinter.GROOVE)
    text2.place(height=20, width=130, x=10, y=50)
    close_but = tkinter.Button(root, text="Close", command=lambda: (root.destroy(), pygame.quit(), quit()))
    close_but.place(height=20, width=40, x=110, y=75)
    cont_but = tkinter.Button(root, text="Again", command=lambda: (root.destroy(), main()))
    cont_but.place(height=20, width=40, x=60, y=75)
    root.mainloop()


main()
